<?php

namespace App\Requests;

class UserRequest
{
    private array $errors = [];
    private array $data = [];

    public function __construct(array $input)
    {
        $this->data = $this->sanitize($input);
    }

    /**
     * Sanitiza los campos de entrada
     */
    private function sanitize(array $input): array
    {
        return [
            'name'     => isset($input['name']) ? htmlspecialchars(trim($input['name']), ENT_QUOTES, 'UTF-8') : '',
            'email'    => isset($input['email']) ? filter_var(trim($input['email']), FILTER_SANITIZE_EMAIL) : '',
            'password' => isset($input['password']) ? trim($input['password']) : '',
            'confirm_password' => isset($input['confirm_password']) ? trim($input['confirm_password']) : '',
        ];
    }

    /**
     * Valida los datos para el registro
     */
    public function validateRegister(): bool
    {
        $this->errors = [];

        // Nombre
        if (empty($this->data['name'])) {
            $this->errors['name'] = 'El nombre es obligatorio.';
        } elseif (strlen($this->data['name']) < 3) {
            $this->errors['name'] = 'El nombre debe tener al menos 3 caracteres.';
        } elseif (strlen($this->data['name']) > 100) {
            $this->errors['name'] = 'El nombre no puede superar los 100 caracteres.';
        }

        // Email
        if (empty($this->data['email'])) {
            $this->errors['email'] = 'El email es obligatorio.';
        } elseif (!filter_var($this->data['email'], FILTER_VALIDATE_EMAIL)) {
            $this->errors['email'] = 'El formato del email no es válido.';
        } elseif (strlen($this->data['email']) > 100) {
            $this->errors['email'] = 'El email no puede superar los 100 caracteres.';
        }

        if (empty($this->data['password'])) {
            $this->errors['password'] = 'La contraseña es obligatoria.';
        } elseif (strlen($this->data['password']) < 8) {
            $this->errors['password'] = 'La contraseña debe tener al menos 8 caracteres.';
        } elseif (strlen($this->data['password']) > 50) {
            $this->errors['password'] = 'La contraseña no puede superar los 50 caracteres.';
            //comprueba q tenga al menos una ltra, al menos un numeros, y un caracter raro
        } elseif (!preg_match('/[A-Za-z]/', $this->data['password']) || !preg_match('/\d/', $this->data['password']) || !preg_match('/[^A-Za-z\d]/', $this->data['password'])) {
            $this->errors['password'] = 'La contraseña debe incluir letras, numeros y al menos un simbolo.';
        }

        if (empty($this->data['confirm_password'])) {
            $this->errors['confirm_password'] = 'Debes confirmar la contraseña.';
        } elseif ($this->data['password'] !== $this->data['confirm_password']) {
            $this->errors['confirm_password'] = 'Las contraseñas no coinciden.';
        }

        return empty($this->errors);
    }

    /**
     * Valida los datos para el login
     */
    public function validateLogin(): bool
    {
        $this->errors = [];

        if (empty($this->data['email'])) {
            $this->errors['email'] = 'El email es obligatorio.';
        } elseif (!filter_var($this->data['email'], FILTER_VALIDATE_EMAIL)) {
            $this->errors['email'] = 'El formato del email no es válido.';
        }

        if (empty($this->data['password'])) {
            $this->errors['password'] = 'La contraseña es obligatoria.';
        }

        return empty($this->errors);
    }

    /**
     * Devuelve los errores de validación
     */
    public function getErrors(): array
    {
        return $this->errors;
    }

    /**
     * Devuelve un campo sanitizado
     */
    public function get(string $field): string
    {
        return $this->data[$field] ?? '';
    }

    /**
     * Devuelve todos los datos sanitizados
     */
    public function all(): array
    {
        return $this->data;
    }
}
