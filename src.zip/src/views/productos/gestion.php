<?php
/** @var App\Models\Product[] $productos */
/** @var array<int, string> $categoryMap */
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h1 class="h3 mb-0"><i class="bi bi-box-seam me-2"></i>Inventario de Productos</h1>
    <a href="<?= BASE_URL ?>productos/crear" class="btn btn-dark">
        <i class="bi bi-plus-lg me-1"></i>Nuevo Producto
    </a>
</div>

<?php if (isset($_SESSION['product_save']) && $_SESSION['product_save'] === 'complete'): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <i class="bi bi-check-circle me-2"></i>Producto guardado correctamente.
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
    <?php unset($_SESSION['product_save']); ?>
<?php endif; ?>

<?php if (isset($_SESSION['product_delete']) && $_SESSION['product_delete'] === 'complete'): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <i class="bi bi-check-circle me-2"></i>Producto eliminado correctamente.
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
    <?php unset($_SESSION['product_delete']); ?>
<?php endif; ?>

<?php if (!empty($_SESSION['product_error'])): ?>
    <div class="alert alert-danger alert-dismissible fade show" role="alert">
        <i class="bi bi-exclamation-triangle me-2"></i><?= htmlspecialchars($_SESSION['product_error'], ENT_QUOTES, 'UTF-8') ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
    <?php unset($_SESSION['product_error']); ?>
<?php endif; ?>

<?php if (empty($productos)): ?>
    <div class="text-center py-5 text-muted">
        <i class="bi bi-inbox fs-1"></i>
        <p class="mt-2">No hay productos registrados.</p>
    </div>
<?php else: ?>
    <div class="table-responsive">
        <table class="table table-hover align-middle">
            <thead class="table-dark">
                <tr>
                    <th style="width:60px">#</th>
                    <th style="width:80px">Imagen</th>
                    <th>Nombre</th>
                    <th>Categoría</th>
                    <th>Precio</th>
                    <th>Stock</th>
                    <th class="text-end">Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($productos as $producto): ?>
                    <tr>
                        <td class="text-muted"><?= (int)$producto->id ?></td>
                        <td>
                            <?php if (!empty($producto->image)): ?>
                                <img src="<?= UPLOADS_URL . htmlspecialchars($producto->image, ENT_QUOTES, 'UTF-8') ?>"
                                    alt="Imagen"
                                    class="rounded" style="width:52px;height:52px;object-fit:cover;">
                            <?php else: ?>
                                <div class="rounded bg-light d-flex align-items-center justify-content-center" style="width:52px;height:52px;">
                                    <i class="bi bi-image text-muted"></i>
                                </div>
                            <?php endif; ?>
                        </td>
                        <td class="fw-semibold"><?= htmlspecialchars($producto->name, ENT_QUOTES, 'UTF-8') ?></td>
                        <td>
                            <span class="badge bg-secondary">
                                <?= htmlspecialchars($categoryMap[$producto->category_id] ?? 'Sin categoría', ENT_QUOTES, 'UTF-8') ?>
                            </span>
                        </td>
                        <td class="fw-semibold text-danger"><?= number_format((float)$producto->price, 2) ?> &euro;</td>
                        <td>
                            <span class="badge <?= (int)$producto->stock > 0 ? 'bg-success' : 'bg-danger' ?>">
                                <?= (int)$producto->stock ?>
                            </span>
                        </td>
                        <td class="text-end">
                            <a href="<?= BASE_URL ?>productos/editar/<?= (int)$producto->id ?>" class="btn btn-sm btn-warning me-1">
                                <i class="bi bi-pencil me-1"></i>Editar
                            </a>
                            <form method="POST" action="<?= BASE_URL ?>productos/eliminar/<?= (int)$producto->id ?>" class="d-inline"
                                onsubmit="return confirm('¿Eliminar el producto «<?= htmlspecialchars($producto->name, ENT_QUOTES, 'UTF-8') ?>»?');">
                                <button type="submit" class="btn btn-sm btn-danger">
                                    <i class="bi bi-trash me-1"></i>Eliminar
                                </button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
<?php endif; ?>
